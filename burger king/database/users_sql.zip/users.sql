-- Create the database if it doesn't exist
CREATE DATABASE IF NOT EXISTS burger_king;
USE burger_king;

-- Drop existing users table if exists
DROP TABLE IF EXISTS users;

-- Create users table
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(255) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL
);

-- Insert a sample user (password is "password123")
INSERT INTO users (email, password) VALUES
('test@example.com', '$2y$10$7jdcYLVzPiRBeSX2j95Hqu/vbBx.zayQcdYdCHvyMPJzkQwLzQaVe');
